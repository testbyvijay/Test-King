const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());

mongoose.connect("YOUR_MONGODB_URL");

const Result = mongoose.model('Result',{
 username:String,
 score:Number
});

app.get('/leaderboard', async (req,res)=>{
 const data = await Result.find().sort({score:-1}).limit(10);
 res.json(data);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=>console.log("Running"));
